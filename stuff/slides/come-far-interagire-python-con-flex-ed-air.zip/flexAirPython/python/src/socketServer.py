import socket, select, time

theAddress = ('localhost', 2223)
theSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
theSock.bind(theAddress)
theSock.listen(5)

input = [theSock]
allClients=[]

while True:
    inputready, outputready, exceptready = select.select(input, [], [])
    for s in inputready:
        if s == theSock: 
            client, address = theSock.accept() 
            input.append(client)                
            connected = True
            now = time.localtime()
            displaytime = time.strftime("%A %d %B %Y, %X",now)
            nickClient = client.recv(1024)
            allClients.append((nickClient, address[0]))
            welcomeMsg = "Welcome " + nickClient
            client.send("Server date time: " + displaytime
			+ "\nPeople in the chat: (" + str(len(allClients))
            +" people)\n")
            client.send("\n" + welcomeMsg + "\n\n")
        else:
            data = s.recv(1024)
            tempConn = input[1:len(input)]
            if data:
                for i in tempConn:
                    i.send(str(data))
        
                
#theSock.close()      